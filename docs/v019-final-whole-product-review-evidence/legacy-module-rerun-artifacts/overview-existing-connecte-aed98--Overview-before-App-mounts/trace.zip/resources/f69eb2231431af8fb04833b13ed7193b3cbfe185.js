const React = __vite__cjsImport0_react;const ReactDOM = __vite__cjsImport1_reactDom_client;const _jsxDEV = __vite__cjsImport6_react_jsxDevRuntime["jsxDEV"];import __vite__cjsImport0_react from "/Genesys-aqm/node_modules/.vite/deps/react.js?v=ad791930";
import __vite__cjsImport1_reactDom_client from "/Genesys-aqm/node_modules/.vite/deps/react-dom_client.js?v=25424dde";
import { Root } from "/Genesys-aqm/src/showcase/Root.tsx";
import "/Genesys-aqm/src/styles.css";
import "/Genesys-aqm/src/brandTokens.css";
import "/Genesys-aqm/src/showcase/showcase.css";
var _jsxFileName = "/Users/simonridd/.codex/worktrees/aqm-v019-final-whole-product-review/Genesys-aqm/src/main.tsx";
import __vite__cjsImport6_react_jsxDevRuntime from "/Genesys-aqm/node_modules/.vite/deps/react_jsx-dev-runtime.js?v=ad791930";
ReactDOM.createRoot(document.getElementById("root")).render(/* @__PURE__ */ _jsxDEV(React.StrictMode, { children: /* @__PURE__ */ _jsxDEV(Root, {}, void 0, false, {
	fileName: _jsxFileName,
	lineNumber: 8,
	columnNumber: 80
}, this) }, void 0, false, {
	fileName: _jsxFileName,
	lineNumber: 8,
	columnNumber: 62
}, this));

//# sourceMappingURL=data:application/json;base64,eyJtYXBwaW5ncyI6IkFBQUEsT0FBTyxXQUFXO0FBQ2xCLE9BQU8sY0FBYztBQUNyQixTQUFTLFlBQVk7QUFDckIsT0FBTztBQUNQLE9BQU87QUFDUCxPQUFPOzs7QUFFUCxTQUFTLFdBQVcsU0FBUyxlQUFlLE1BQU0sQ0FBRSxDQUFDLENBQUMsT0FBTyx3QkFBQyxNQUFNLFlBQVAsWUFBa0Isd0JBQUMsTUFBRCxDQUFPOzs7O1NBQW1COzs7O1FBQUMiLCJuYW1lcyI6W10sInNvdXJjZXMiOlsibWFpbi50c3giXSwidmVyc2lvbiI6Mywic291cmNlc0NvbnRlbnQiOlsiaW1wb3J0IFJlYWN0IGZyb20gJ3JlYWN0J1xuaW1wb3J0IFJlYWN0RE9NIGZyb20gJ3JlYWN0LWRvbS9jbGllbnQnXG5pbXBvcnQgeyBSb290IH0gZnJvbSAnLi9zaG93Y2FzZS9Sb290J1xuaW1wb3J0ICcuL3N0eWxlcy5jc3MnXG5pbXBvcnQgJy4vYnJhbmRUb2tlbnMuY3NzJ1xuaW1wb3J0ICcuL3Nob3djYXNlL3Nob3djYXNlLmNzcydcblxuUmVhY3RET00uY3JlYXRlUm9vdChkb2N1bWVudC5nZXRFbGVtZW50QnlJZCgncm9vdCcpISkucmVuZGVyKDxSZWFjdC5TdHJpY3RNb2RlPjxSb290IC8+PC9SZWFjdC5TdHJpY3RNb2RlPilcbiJdfQ==