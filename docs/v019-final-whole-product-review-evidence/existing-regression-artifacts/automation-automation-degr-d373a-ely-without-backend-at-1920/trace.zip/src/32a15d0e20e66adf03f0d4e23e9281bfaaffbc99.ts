import { installOwnerGovernanceFixture } from './governanceFixture'
import { test, expect } from '@playwright/test'
for(const viewport of [{width:1440,height:900},{width:1920,height:1080},{width:390,height:844}]){
  test(`automation degrades safely without backend at ${viewport.width}`,async({browser})=>{
    const page=await browser.newPage({viewport})
    await installOwnerGovernanceFixture(page);await page.goto('http://127.0.0.1:4174/Genesys-aqm/')
    await page.getByRole('navigation',{name:'Primary navigation'}).getByRole('button',{name:/Overview/}).click()
    await expect(page.getByRole('heading',{name:'Overview',exact:true})).toBeVisible()
    await expect(page.getByText('Connect to the automation service',{exact:true})).toBeVisible()
    await expect(page.getByText('Connect to Genesys Cloud to view operational AQM health.')).toBeVisible()
    const panel=page.locator('.overview-page')
    const box=await panel.boundingBox()
    await page.screenshot({path:`/private/tmp/aqm-automation-${viewport.width}.png`,fullPage:true})
    expect(box).not.toBeNull()
    expect(box!.x).toBeGreaterThanOrEqual(0)
    expect(box!.x+box!.width).toBeLessThanOrEqual(viewport.width+1)
    await page.getByRole('navigation',{name:'Primary navigation'}).getByRole('button',{name:/Conversation review/}).click()
    await expect(page.getByRole('button',{name:'Synthetic',exact:true})).toBeVisible()
    await page.getByRole('navigation',{name:'Primary navigation'}).getByRole('button',{name:/Settings/}).click()
    await expect(page.getByRole('heading',{name:'Genesys Cloud'})).toBeVisible()
    await expect(page.getByRole('heading',{name:'Browser Jev evaluation key'})).toBeHidden()
    await page.getByText('Legacy browser sandbox (local development)',{exact:true}).click()
    await expect(page.getByRole('heading',{name:'Browser Jev evaluation key'})).toBeVisible()
    await page.close()
  })
}
